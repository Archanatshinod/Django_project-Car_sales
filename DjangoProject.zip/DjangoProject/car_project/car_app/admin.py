from django.contrib import admin

from .models import Login, User 


# Register your models here.
admin.site.register(Login)
admin.site.register(User)