from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import *

# Create your views here.

from django.contrib import messages

# -----------------------------------------------------LOGIN------------------------------------------
def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')  
        password = request.POST.get('password')

        try:
            user = Login.objects.get(Username=username, Password=password)
        
            request.session['user_id'] = user.id
            request.session['username'] = user.Username  
            return redirect('home_page') 
        except Login.DoesNotExist:
            return render(request, 'login.html', {'error': 'Invalid username or password'})

    return render(request, 'login.html')


# ---------------------------------USER REGISTRATION-------------------------------------------------

def user_registration(request):
    if request.method == 'POST':
        name = request.POST['Name']
        email = request.POST['Email']
        phone = request.POST['Phone']
        whatsapp_number = request.POST['Whatsapp_number']
        profile_photo = request.FILES.get('Profile_photo')
        password = request.POST['Password']
        confirm_password = request.POST['Confirm_password']

        if not name:
            return render(request, 'user_registration.html', {'x': 'Name field is required!'})
        
        if Login.objects.filter(Username=name).exists():
            return render(request, 'user_registration.html', {'x': 'Username already exists!'})

        if password != confirm_password:
            return render(request, 'user_registration.html', {'x': 'Passwords do not match!'})

        login_entry = Login.objects.create(Username=name, Password=password)
        User.objects.create(
            login=login_entry,
            Name=name,
            Email=email,
            Phone=phone,
            whatsapp_number=whatsapp_number,
            profile_picture=profile_photo
        )

        return redirect('Login')  

    return render(request, 'user_registration.html')

# ------------------------------------------HOME PAGE------------------------------------------------------

def home_page(request):
    username = request.session.get('username')

    if not username:
        return redirect('Login')
    
    return render(request, 'User_home.html', {'username': username})


# -------------------------------------LOGOUT-------------------------------------------------------------

def logout(request):
    request.session.flush()  
    messages.success(request, "You have been logged out successfully!") 
    return redirect('Login')